﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter05_2
{
    class product
    {
        public string name;
        public int price;
        public static int count; 
        //static 있으면 클래스변수 없으면 인스턴스 변수
    }
}
